# 🔐 Crypt-- · by CryptWarden
## Vercel Deployment Guide

### Folder Structure
```
cryptwarden-vercel/
├── api/
│   └── chat.js        ← Serverless API (auto-detected by Vercel)
├── public/
│   └── index.html
├── src/
│   ├── index.js
│   └── App.js
├── package.json
├── vercel.json
└── .gitignore
```

---

### Step 1 — Push to GitHub
```bash
git init
git add .
git commit -m "Crypt-- by CryptWarden"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/cryptwarden.git
git push -u origin main
```

### Step 2 — Deploy on Vercel
1. Go to https://vercel.com → sign in with GitHub
2. Click **Add New Project**
3. Import your repo
4. Framework: **Create React App**
5. Root Directory: leave as `/` (default)
6. Click **Deploy**

### Step 3 — Add API Key
1. Vercel dashboard → your project → **Settings → Environment Variables**
2. Add:
   - Name: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-your-key-here` (from console.anthropic.com)
   - Check all 3 environments (Production, Preview, Development)
3. **Save** → then go to **Deployments** → **Redeploy**

### Done! 🎉
Your site: `https://cryptwarden.vercel.app`
