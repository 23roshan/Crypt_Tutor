import { useState, useRef, useEffect } from "react";

const STREAMS = {
  "🚀 IIT / JEE": {
    subjects: ["⚡ Physics", "🧪 Chemistry", "📐 Maths"],
    topics: ["Explain Quantum Tunneling", "What is Entropy?", "Explain Integration", "What is SHM?", "Electric Field Lines", "Chemical Equilibrium"]
  },
  "🩺 NEET / PCB": {
    subjects: ["🔬 Biology", "🧪 Chemistry", "⚡ Physics"],
    topics: ["DNA Replication", "How does Osmosis work?", "Action Potential", "Photosynthesis", "Enzyme Inhibition", "Mendelian Genetics"]
  },
  "📊 Commerce": {
    subjects: ["📈 Accountancy", "💼 Business Studies", "📉 Economics", "🔢 Maths"],
    topics: ["Accounting Equation", "Supply and Demand", "What is GDP?", "Journal Entries", "Opportunity Cost", "Market Structures"]
  },
  "🎨 Arts / Humanities": {
    subjects: ["🏛️ History", "🌍 Geography", "🏛️ Polity", "🧠 Psychology", "📖 Sociology"],
    topics: ["French Revolution", "What is Federalism?", "Plate Tectonics", "Classical Conditioning", "Social Stratification", "Fundamental Rights"]
  },
  "💻 CS / Tech": {
    subjects: ["💻 Programming", "🧮 Data Structures", "🌐 Networking", "🗄️ Databases"],
    topics: ["Explain Recursion", "Binary Search", "How TCP/IP works", "DB Normalization", "OOP Concepts", "Time Complexity"]
  }
};

const LANGS = ["🇮🇳 Hinglish", "🇬🇧 English"];

function parseGuru(text) {
  const am = text.match(/\[ANALOGY\]([\s\S]*?)\[\/ANALOGY\]/);
  const qm = text.match(/\[QUESTION\]([\s\S]*?)\[\/QUESTION\]/);
  const main = text
    .replace(/\[ANALOGY\][\s\S]*?\[\/ANALOGY\]/g, "")
    .replace(/\[QUESTION\][\s\S]*?\[\/QUESTION\]/g, "")
    .trim();
  return { main, analogy: am?.[1]?.trim() || null, question: qm?.[1]?.trim() || null };
}

function RichText({ t }) {
  if (!t) return null;
  return (
    <>{t.split("\n").map((line, i, a) => (
      <span key={i}>
        {line.split(/(\*\*[^*]+\*\*)/).map((seg, j) =>
          seg.startsWith("**") && seg.endsWith("**")
            ? <strong key={j} style={{ color: "#a78bfa" }}>{seg.slice(2, -2)}</strong>
            : seg
        )}
        {i < a.length - 1 && <br />}
      </span>
    ))}</>
  );
}

function Dots() {
  return (
    <div style={{ display: "flex", gap: 5, padding: "6px 2px" }}>
      {[0, 1, 2].map(i => (
        <div key={i} style={{
          width: 7, height: 7, borderRadius: "50%", background: "#4a4a6a",
          animation: `db 1.2s ${i * 0.2}s infinite`
        }} />
      ))}
      <style>{`
        @keyframes db{0%,80%,100%{opacity:.2;transform:scale(.7)}40%{opacity:1;transform:scale(1)}}
        @keyframes pulse{0%,100%{box-shadow:0 0 0 0 rgba(139,92,246,0.4)}50%{box-shadow:0 0 0 8px rgba(139,92,246,0)}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        @keyframes floatIcon{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-track{background:transparent}
        ::-webkit-scrollbar-thumb{background:#1e1e35;border-radius:4px}
      `}</style>
    </div>
  );
}

function Pill({ label, active, onClick, ac = "#7c3aed" }) {
  return (
    <button onClick={onClick} style={{
      fontSize: 11, fontWeight: active ? 700 : 500,
      padding: "4px 13px", borderRadius: 100, cursor: "pointer",
      border: `1px solid ${active ? ac : "#1e1e35"}`,
      background: active ? ac : "transparent",
      color: active ? "#fff" : "#4a4a6a",
      whiteSpace: "nowrap", flexShrink: 0, transition: "all .15s"
    }}>{label}</button>
  );
}

export default function App() {
  const sk = Object.keys(STREAMS);
  const [stream, setStream] = useState(sk[0]);
  const [subject, setSubject] = useState(STREAMS[sk[0]].subjects[0]);
  const [lang, setLang] = useState(LANGS[0]);
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const hist = useRef([]);
  const bottom = useRef(null);
  const ta = useRef(null);

  useEffect(() => { bottom.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, busy]);

  function resize(el) {
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 120) + "px";
  }

  function switchStream(s) {
    setStream(s);
    setSubject(STREAMS[s].subjects[0]);
  }

  async function send(override) {
    const msg = (override ?? text).trim();
    if (!msg || busy) return;

    setText("");
    setError("");
    if (ta.current) ta.current.style.height = "auto";

    setMsgs(p => [...p, { role: "user", content: msg }]);
    hist.current.push({ role: "user", content: msg });
    setBusy(true);

    const isHinglish = lang === LANGS[0];
    const memCount = Math.floor(hist.current.length / 2);

    const systemPrompt = `You are Crypt-- — a legendary, sharp Indian teacher who cracks open the hardest concepts with brilliant real-world analogies. You have a perfect memory of the ENTIRE conversation (${memCount} exchanges) and always build on what the student already knows.

Stream: ${stream} | Subject: ${subject}
Language: ${isHinglish
  ? "Hinglish — natural Roman-script Hindi+English mix. Like: 'Yaar sun, yeh concept ekdum filmy hai!' Never use Devanagari."
  : "Warm, punchy English. Like a brilliant older sibling who genuinely wants you to win."}

━━━ TEACHING PHILOSOPHY ━━━
1. ANALOGY FIRST — always open with a vivid desi analogy (IPL, chai, trains, Bollywood, street food, WhatsApp, autorickshaw, PUBG, etc.). Make it so relatable the concept just clicks.
2. INTUITION BEFORE FORMULA — never lead with equations. Build the "why" first, the formula follows naturally.
3. MEMORY — reference earlier topics from this conversation to show the student their own progress. Connect dots across concepts.
4. TONE — older sibling energy. Warm, confident, zero condescension. The student is smart — you're just unlocking what's already there.

━━━ THE SECRET WEAPON — INDIRECT HARD QUESTIONS ━━━
After explaining, you MUST sneak in ONE question that tests a DEEP, EXAM-LEVEL concept — but disguised completely as a fun story or real scenario.

RULES for the sneaky question:
- NEVER say "hard question", "difficult", "challenging", "test yourself", or anything that signals pressure
- Frame it as curiosity: "Yaar, ek interesting situation socho...", "Tere dost ne bet lagaya ki...", "IPL mein commentator ne kuch bola...", "Imagine teri mummy ne pucha ki..."
- The question should require the student to APPLY the concept, not just recall it
- It should be at the level of JEE/NEET/board exam difficulty — but feel like casual conversation
- If the student answers, respond with encouragement and build on their answer

━━━ STRICT OUTPUT FORMAT ━━━
Write main explanation (2–4 punchy paragraphs, max 220 words)
[ANALOGY]the analogy — vivid, specific, desi[/ANALOGY]
[QUESTION]the sneaky story-question — feels casual, tests deep understanding[/QUESTION]

Total response: max 370 words. High energy. Make learning feel like a cheat code.`;

    const fullConversation = hist.current
      .map(m => `${m.role === "user" ? "Student" : "Crypt--"}: ${m.content}`)
      .join("\n\n");

    const promptToSend = `${systemPrompt}

--- FULL CONVERSATION HISTORY ---
${fullConversation}
--- END ---

Respond as Crypt-- to the student's latest message. Follow the format strictly.`;

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1024,
          messages: [{ role: "user", content: promptToSend }]
        })
      });

      const data = await response.json();
      if (data.error) throw new Error(data.error.message);

      const reply = (data.content || [])
        .filter(b => b.type === "text")
        .map(b => b.text)
        .join("") || (isHinglish ? "Kuch gadbad ho gayi yaar!" : "Something went wrong, please try again!");

      hist.current.push({ role: "assistant", content: reply });
      setMsgs(p => [...p, { role: "assistant", content: reply, parsed: parseGuru(reply) }]);

    } catch (e) {
      const errMsg = e.message || "Something went wrong.";
      setError(errMsg);
      hist.current.push({ role: "assistant", content: "⚠️ " + errMsg });
      setMsgs(p => [...p, {
        role: "assistant", content: "⚠️ " + errMsg,
        parsed: { main: "⚠️ " + errMsg, analogy: null, question: null }
      }]);
    }

    setBusy(false);
  }

  const subjects = STREAMS[stream].subjects;
  const topics = STREAMS[stream].topics;
  const memCount = Math.floor(hist.current.length / 2);

  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column", background: "#07070f", color: "#e2e2f0", fontFamily: "'Segoe UI', Arial, sans-serif", overflow: "hidden" }}>

      {/* Glow bg */}
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        background: "radial-gradient(ellipse 70% 50% at 5% 10%,rgba(109,40,217,0.18) 0%,transparent 55%),radial-gradient(ellipse 50% 40% at 95% 90%,rgba(109,40,217,0.12) 0%,transparent 55%)"
      }} />

      {/* HEADER */}
      <div style={{ zIndex: 10, padding: "12px 20px", display: "flex", alignItems: "center", gap: 12, borderBottom: "1px solid #1a1a2e", background: "rgba(7,7,15,0.97)", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 32, height: 32, borderRadius: 9, background: "linear-gradient(135deg,#6d28d9,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, boxShadow: "0 0 14px rgba(139,92,246,0.4)", animation: "pulse 2.5s infinite" }}>🔐</div>
          <div style={{ fontWeight: 800, fontSize: 19, letterSpacing: -0.5 }}>Crypt<span style={{ color: "#8b5cf6" }}>--</span></div>
        </div>
        <div style={{ fontSize: 10, fontWeight: 700, background: "linear-gradient(135deg,#6d28d9,#8b5cf6)", color: "#fff", padding: "2px 10px", borderRadius: 20, textTransform: "uppercase", letterSpacing: 0.8 }}>Analogy Mode</div>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: memCount > 0 ? "#7c3aed" : "#2a2a45" }}>
          <div style={{ width: 7, height: 7, borderRadius: "50%", background: memCount > 0 ? "#8b5cf6" : "#2a2a45", boxShadow: memCount > 0 ? "0 0 6px #8b5cf6" : "none" }} />
          {memCount > 0 ? `${memCount} exchange${memCount > 1 ? "s" : ""} remembered` : "Fresh session"}
        </div>
      </div>

      {/* CONTROLS */}
      <div style={{ zIndex: 10, background: "rgba(7,7,15,0.94)", borderBottom: "1px solid #1a1a2e", flexShrink: 0 }}>
        <div style={{ display: "flex", gap: 6, padding: "8px 20px 0", overflowX: "auto" }}>
          {sk.map(s => <Pill key={s} label={s} active={s === stream} onClick={() => switchStream(s)} ac="#6d28d9" />)}
        </div>
        <div style={{ display: "flex", gap: 6, padding: "6px 20px 9px", overflowX: "auto", alignItems: "center" }}>
          {subjects.map(s => <Pill key={s} label={s} active={s === subject} onClick={() => setSubject(s)} ac="#8b5cf6" />)}
          <div style={{ width: 1, height: 16, background: "#1e1e35", flexShrink: 0, margin: "0 3px" }} />
          {LANGS.map(l => <Pill key={l} label={l} active={l === lang} onClick={() => setLang(l)} ac="#5b21b6" />)}
        </div>
      </div>

      {/* ERROR BAR */}
      {error && (
        <div style={{ zIndex: 10, background: "#1a0a0a", borderBottom: "1px solid #3a1a1a", padding: "7px 20px", fontSize: 12, color: "#f87171", display: "flex", justifyContent: "space-between", alignItems: "center", flexShrink: 0 }}>
          ⚠️ {error}
          <button onClick={() => setError("")} style={{ background: "none", border: "none", color: "#f87171", cursor: "pointer", fontSize: 14 }}>✕</button>
        </div>
      )}

      {/* CHAT */}
      <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 16, padding: "18px 16px 8px", maxWidth: 840, width: "100%", margin: "0 auto", zIndex: 10, minHeight: 0 }}>

        {msgs.length === 0 && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", padding: "28px 12px", gap: 14 }}>
            <div style={{ width: 70, height: 70, borderRadius: 20, fontSize: 32, background: "linear-gradient(135deg,#6d28d9,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 0 32px rgba(139,92,246,0.4)", animation: "floatIcon 3s ease-in-out infinite" }}>🔐</div>
            <div style={{ fontWeight: 800, fontSize: 22 }}>Meet <span style={{ color: "#8b5cf6" }}>Crypt--</span></div>
            <div style={{ color: "#4a4a6a", fontSize: 13.5, maxWidth: 420, lineHeight: 1.7 }}>
              {lang === LANGS[0]
                ? "Har concept ko analogy se decode karta hoon — aur exam-level questions itne casually poochunga ki pata bhi nahi chalega. 🔓"
                : "Every concept decoded through analogies. Exam-level questions hidden inside casual stories — you won't even feel the pressure. 🔓"}
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 7, justifyContent: "center", marginTop: 4 }}>
              {topics.map(t => (
                <button key={t} onClick={() => send(t)}
                  style={{ fontSize: 12, padding: "6px 14px", borderRadius: 100, border: "1px solid #1e1e35", background: "#0e0e1e", color: "#9090c0", cursor: "pointer", transition: "all .15s" }}
                  onMouseEnter={e => { e.target.style.borderColor = "#8b5cf6"; e.target.style.color = "#c4b5fd"; }}
                  onMouseLeave={e => { e.target.style.borderColor = "#1e1e35"; e.target.style.color = "#9090c0"; }}
                >{t}</button>
              ))}
            </div>
          </div>
        )}

        {msgs.map((m, i) => {
          const isU = m.role === "user";
          const p = m.parsed;
          return (
            <div key={i} style={{ display: "flex", gap: 10, flexDirection: isU ? "row-reverse" : "row", animation: "fadeUp .28s ease" }}>
              <div style={{ width: 32, height: 32, borderRadius: 9, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, background: isU ? "#0e0e1e" : "linear-gradient(135deg,#6d28d9,#8b5cf6)", border: isU ? "1px solid #1e1e35" : "none", boxShadow: isU ? "none" : "0 0 10px rgba(139,92,246,0.3)" }}>
                {isU ? "👤" : "🔐"}
              </div>
              <div style={{ maxWidth: "83%", padding: "12px 16px", borderRadius: 14, fontSize: 14, lineHeight: 1.78, background: isU ? "linear-gradient(135deg,#4c1d95,rgba(109,40,217,0.6))" : "#0e0e1e", border: isU ? "none" : "1px solid #1a1a2e", borderTopLeftRadius: isU ? 14 : 3, borderTopRightRadius: isU ? 3 : 14 }}>
                {isU ? m.content : (
                  <div style={{ display: "flex", flexDirection: "column", gap: 11 }}>
                    <div><RichText t={p?.main || m.content} /></div>
                    {p?.analogy && (
                      <div style={{ background: "rgba(139,92,246,0.08)", borderLeft: "3px solid #8b5cf6", borderRadius: "0 9px 9px 0", padding: "10px 13px", fontSize: 13.5, color: "#c4b5fd" }}>
                        <div style={{ fontSize: 10, fontWeight: 700, color: "#8b5cf6", letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 5 }}>🔗 Analogy</div>
                        <RichText t={p.analogy} />
                      </div>
                    )}
                    {p?.question && (
                      <div style={{ background: "rgba(167,139,250,0.07)", borderLeft: "3px solid #a78bfa", borderRadius: "0 9px 9px 0", padding: "10px 13px", fontSize: 13.5, color: "#ddd6fe" }}>
                        <div style={{ fontSize: 10, fontWeight: 700, color: "#a78bfa", letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 5 }}>🎯 Think About It</div>
                        <RichText t={p.question} />
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {busy && (
          <div style={{ display: "flex", gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: 9, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, background: "linear-gradient(135deg,#6d28d9,#8b5cf6)", boxShadow: "0 0 10px rgba(139,92,246,0.3)" }}>🔐</div>
            <div style={{ padding: "12px 15px", borderRadius: 14, borderTopLeftRadius: 3, background: "#0e0e1e", border: "1px solid #1a1a2e" }}><Dots /></div>
          </div>
        )}
        <div ref={bottom} />
      </div>

      {/* INPUT */}
      <div style={{ flexShrink: 0, maxWidth: 840, width: "100%", margin: "0 auto", zIndex: 10, padding: "8px 16px 0" }}>
        <div style={{ display: "flex", gap: 10, alignItems: "flex-end", background: "#0e0e1e", border: "1px solid #1e1e35", borderRadius: 13, padding: "10px 12px" }}>
          <textarea
            ref={ta}
            value={text}
            onChange={e => { setText(e.target.value); resize(e.target); }}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder={lang === LANGS[0] ? "Koi bhi concept poochho..." : "Ask any concept..."}
            rows={1}
            style={{ flex: 1, background: "transparent", border: "none", outline: "none", fontFamily: "inherit", fontSize: 14, color: "#e2e2f0", resize: "none", lineHeight: 1.55, maxHeight: 120, overflowY: "auto" }}
          />
          <button onClick={() => send()} disabled={busy || !text.trim()} style={{
            width: 34, height: 34, borderRadius: 9, flexShrink: 0,
            background: "linear-gradient(135deg,#6d28d9,#8b5cf6)", border: "none",
            cursor: busy || !text.trim() ? "not-allowed" : "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            opacity: busy || !text.trim() ? 0.3 : 1, color: "white",
            boxShadow: busy || !text.trim() ? "none" : "0 0 12px rgba(139,92,246,0.4)",
            transition: "opacity .2s, box-shadow .2s"
          }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" />
            </svg>
          </button>
        </div>
        <div style={{ textAlign: "center", fontSize: 11, color: "#2a2a45", padding: "8px 0 12px", letterSpacing: 0.3 }}>
          Made by <span style={{ color: "#6d28d9", fontWeight: 700 }}>CryptWarden</span> · Full memory · {lang}
        </div>
      </div>
    </div>
  );
}
